#pragma once

bool CheckGLErrors(char * s);